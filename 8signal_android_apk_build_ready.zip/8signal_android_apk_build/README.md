# 8SIGNAL Gold — Android display + experimental backend

Android Studio project (Kotlin, minSdk 26). Open this folder in Android Studio, sync Gradle, and Build > Build APK(s). An APK has **not** been built or verified here.

## What works in source
- Dark Persian UI, editable HTTPS API endpoint stored locally, fetch button and structured response rendering.
- Backend (`backend/server.py`) exposes `/api/daily` with an experimental GC futures POC derived from actual trades if a valid Databento API key and entitlements are provided.
- Offline CSV mode from previous prototype retained.
- Server errors or missing data produce NO_TRADE. No fake buy/sell signals or entry/SL/TP.

## Backend quick start
`pip install databento`
`export DATABENTO_API_KEY=...`
`python backend/server.py`

Backend binds 127.0.0.1:8080 by default. To access from phone, deploy behind an authenticated HTTPS reverse proxy, or use a secure tunnel. Do not put the API key in the Android app. Set the HTTPS URL in the app to `https://YOUR_HOST/api/daily`.

## Known limitations
- GC futures prices are **not** XAUUSD spot prices. No conversion or spot feed has been integrated.
- Tokyo midnight is a chosen day boundary, not a universal exchange session boundary. Weekends and holidays can cause NO_TRADE.
- No Android daily background scheduler, push notification, live chart, real XAUUSD entry/SL/TP or validated predictive model yet.
- The backend fetches on demand; historical request costs and permissions depend on Databento.
- Do not trade using this prototype.
