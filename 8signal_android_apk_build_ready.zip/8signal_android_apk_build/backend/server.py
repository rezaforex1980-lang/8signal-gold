"""8SIGNAL experimental server. pip install databento; DATABENTO_API_KEY required.
GC futures POC is NOT XAUUSD POC. This service never issues executable XAUUSD entries.
"""
import os, json, math
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from http.server import BaseHTTPRequestHandler, HTTPServer

TOKYO=ZoneInfo('Asia/Tokyo')

def analyze(trades, now=None):
    now=now or datetime.now(timezone.utc)
    local=now.astimezone(TOKYO)
    today=local.date()
    # Prior Tokyo calendar day; do not silently use a partial session.
    prior=today-timedelta(days=1)
    selected=[(t,p,s) for t,p,s in trades if t.astimezone(TOKYO).date()==prior and s>0 and p>0]
    if not selected:
        return {'status':'no_data','signal':'NO_TRADE','reason':'No trades for the preceding Tokyo day','session_date':str(prior)}
    profile={}
    for t,p,s in selected:
        bucket=round(p*10)/10  # GC minimum tick normally 0.10
        profile[bucket]=profile.get(bucket,0)+s
    poc=max(profile,key=lambda p:(profile[p],-p))
    current=[(t,p,s) for t,p,s in trades if t.astimezone(TOKYO).date()==today]
    # Avoid inferring a validated retest from a single price print.
    return {'status':'ok','instrument':'GC futures (not XAUUSD)','session_date':str(prior),
            'poc_gc':poc,'profile_volume':profile[poc],'trade_count':len(selected),
            'latest_gc_price':current[-1][1] if current else None,
            'signal':'NO_TRADE','reason':'POC calculated; XAUUSD feed and M5 breakout/retest confirmation not connected. No entry/SL/TP issued.',
            'updated_at':now.isoformat()}

def fetch():
    key=os.getenv('DATABENTO_API_KEY')
    if not key: return {'status':'configuration_required','signal':'NO_TRADE','reason':'Set DATABENTO_API_KEY on server'}
    try:
        import databento as db
        now=datetime.now(timezone.utc)
        start=(now.astimezone(TOKYO).date()-timedelta(days=2))
        start=datetime.combine(start,datetime.min.time(),TOKYO).astimezone(timezone.utc)
        data=db.Historical(key).timeseries.get_range(dataset='GLBX.MDP3',symbols='GC.c.0',stype_in='continuous',schema='trades',start=start.isoformat(),end=now.isoformat())
        df=data.to_df()
        trades=[]
        for ts,r in df.iterrows():
            t=ts.to_pydatetime() if hasattr(ts,'to_pydatetime') else ts
            if t.tzinfo is None: t=t.replace(tzinfo=timezone.utc)
            trades.append((t,float(r['price']),int(r['size'])))
        return analyze(trades,now)
    except Exception as exc:
        return {'status':'provider_error','signal':'NO_TRADE','reason':str(exc)[:250]}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path!='/api/daily': self.send_error(404); return
        body=json.dumps(fetch(),ensure_ascii=False).encode()
        self.send_response(200); self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)

if __name__=='__main__':
    HTTPServer(('127.0.0.1',int(os.getenv('PORT','8080'))),Handler).serve_forever()
