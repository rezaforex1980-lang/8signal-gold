package com.eightsignal.gold

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.text.InputType
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private val bg = Color.rgb(10, 16, 28)
    private val card = Color.rgb(25, 36, 55)
    private val gold = Color.rgb(245, 190, 65)
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var history: TextView
    private lateinit var fetch: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        val outer = ScrollView(this).apply { setBackgroundColor(bg); fillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 30, 22, 35)
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }
        outer.addView(root)
        fun label(text: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text; textSize = size; setTextColor(color)
                gravity = Gravity.RIGHT; setPadding(4, 9, 4, 9)
                if (bold) setTypeface(null, Typeface.BOLD)
            }
        fun panel(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 18)
            setBackgroundColor(card)
            val params = LinearLayout.LayoutParams(-1, -2)
            params.bottomMargin = 16
            root.addView(this, params)
        }
        root.addView(label("8SIGNAL  |  تحلیل‌گر طلا", 24f, gold, true))
        root.addView(label("انس جهانی طلا • تایم‌فریم ۵ دقیقه • شروع سشن آسیا", 13f, Color.LTGRAY))
        val signalPanel = panel()
        signalPanel.addView(label("وضعیت تحلیل امروز", 14f, Color.LTGRAY))
        status = label("منتظر اتصال به سرور", 22f, gold, true)
        signalPanel.addView(status)
        details = label("هنوز تحلیل معتبری دریافت نشده است. در این حالت هیچ پیشنهادی برای معامله نمایش داده نمی‌شود.", 15f)
        signalPanel.addView(details)
        val rules = panel()
        rules.addView(label("قوانین استراتژی", 18f, gold, true))
        rules.addView(label("۱. محاسبه پروفایل حجمی روز قبل از معاملات GC\n۲. استخراج فقط سطح POC\n۳. بررسی کندل‌های ۵ دقیقه‌ای XAUUSD\n۴. بررسی تثبیت و پولبک نسبت به POC\n۵. پیشنهاد ورود، حد ضرر و حد سود فقط پس از اعتبارسنجی داده و قوانین", 14f))
        val config = panel()
        config.addView(label("آدرس امن سرور تحلیل", 17f, gold, true))
        val endpoint = EditText(this).apply {
            setText(getPreferences(MODE_PRIVATE).getString("endpoint", ""))
            hint = "https://example.com/api/daily"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            textDirection = android.view.View.TEXT_DIRECTION_LTR
            setSingleLine(true)
        }
        config.addView(endpoint)
        fetch = Button(this).apply { text = "دریافت تحلیل روزانه"; setTextColor(Color.BLACK); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold)) }
        config.addView(fetch)
        fetch.setOnClickListener {
            val address = endpoint.text.toString().trim()
            if (!address.startsWith("https://")) {
                status.text = "آدرس سرور نامعتبر است"
                details.text = "برای اتصال، نشانی HTTPS سرور شخصی خودت را وارد کن."
                return@setOnClickListener
            }
            getPreferences(MODE_PRIVATE).edit().putString("endpoint", address).apply()
            status.text = "در حال دریافت..."; fetch.isEnabled = false
            worker.execute {
                val response = try {
                    val connection = URL(address).openConnection() as HttpURLConnection
                    connection.connectTimeout = 12000; connection.readTimeout = 15000
                    try {
                        if (connection.responseCode != 200) error("خطای سرور: ${connection.responseCode}")
                        val raw = connection.inputStream.bufferedReader().use { it.readText() }
                        val json = JSONObject(raw)
                        val state = json.optString("status", "unknown")
                        val reason = json.optString("reason", "دلیلی ارائه نشده")
                        val date = json.optString("session_date", "نامشخص")
                        val poc = if (json.isNull("poc_gc")) "ناموجود" else json.optString("poc_gc", "ناموجود")
                        // Until GC/spot alignment and validation are implemented, never display actionable trade levels.
                        val summary = "تاریخ: $date\nPOC فیوچرز GC: $poc\nوضعیت داده: $state\nتوضیح: $reason\n\nقیمت فیوچرز GC مستقیماً با XAUUSD یکسان نیست. تا اعتبارسنجی کامل، ورود، حد ضرر و حد سود غیرفعال‌اند."
                        Pair("بدون معامله — حالت آزمایشی", summary)
                    } finally { connection.disconnect() }
                } catch (e: Exception) { Pair("دریافت ناموفق", "اتصال برقرار نشد: ${e.message}\nهیچ سیگنالی صادر نشد.") }
                runOnUiThread {
                    status.text = response.first; details.text = response.second
                    fetch.isEnabled = true
                    if (response.first.startsWith("بدون معامله")) {
                        val old = getPreferences(MODE_PRIVATE).getString("last_report", "") ?: ""
                        getPreferences(MODE_PRIVATE).edit().putString("last_report", response.second).apply()
                        history.text = response.second
                    }
                }
            }
        }
        val logPanel = panel()
        logPanel.addView(label("آخرین گزارش ذخیره‌شده", 17f, gold, true))
        history = label(getPreferences(MODE_PRIVATE).getString("last_report", "هنوز گزارشی ذخیره نشده است.") ?: "", 13f, Color.LTGRAY)
        logPanel.addView(history)
        root.addView(label("نسخه آزمایشی فارسی • تحلیل زنده و اعلان خودکار هنوز فعال نیستند • بدون اجرای خودکار معامله", 12f, Color.LTGRAY))
        setContentView(outer)
    }
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
}
